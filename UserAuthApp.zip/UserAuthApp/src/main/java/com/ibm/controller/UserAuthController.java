package com.ibm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.model.AuthRequest;
import com.ibm.model.AuthResponse;
import com.ibm.service.UserAuthService;
import com.ibm.util.JsonTokenUtil;

@RestController

public class UserAuthController {
	@Autowired
	AuthenticationManager manager;
	
	@Autowired
	UserAuthService service;
	
	@Autowired
	JsonTokenUtil jsonTokenUtil;
	
	
	//@RequestMapping("authenticate")
	@PostMapping(path="/authenticate")
	public ResponseEntity<?> authenticateUserToken(@RequestBody AuthRequest request) throws Exception {
		
		try {
			manager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(),request.getPassword()));
		}
		catch(BadCredentialsException ex) {
			throw new Exception("Incorrect UserName or Password",ex);
		}
		
		final UserDetails details = service.loadUserByUsername(request.getUsername()); 
		System.out.println("details :"+details.getUsername()+"Pass:"+details.getPassword());
		final String jwtToken = jsonTokenUtil.generateJwtToken(details);
		return ResponseEntity.ok(new AuthResponse(jwtToken));
	}
}
