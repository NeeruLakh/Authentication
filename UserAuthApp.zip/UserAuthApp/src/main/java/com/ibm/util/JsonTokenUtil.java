package com.ibm.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
@Service
public class JsonTokenUtil {
	String SECRET_KEY="jwtSecret";
	
	public String generateJwtToken(UserDetails userDetails) {
		Map<String,Object> claims = new HashMap<String,Object>();
		return createJwtToken(claims, userDetails.getUsername());
	}

	public String createJwtToken(Map<String,Object> claims,String object) {
		return Jwts.builder().setClaims(claims).setSubject(object).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis()*1000*60*60*10)).signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
	}

}
