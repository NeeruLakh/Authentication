package com.ibm.model;

public class AuthResponse {
	
	//it will return the JWT token
	private final String jwt;

	public String getJwt() {
		return jwt;
	}

	
	public AuthResponse(String jwt) {
		super();
		this.jwt = jwt;
	}

}
